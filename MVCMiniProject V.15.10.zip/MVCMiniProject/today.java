
package neo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;

public class Prog89 extends JFrame implements ActionListener
{
	JLabel l1,l2;
	JButton first,last,prev,next;
	JTextField t1,t2;
	
	Connection conn;
	ResultSet rs;
	Statement stmt;
	
	today()
	{
		setTitle("Database");
		setBounds(100,100,600,600);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		l1=new JLabel("ID");
		l1.setBounds(50,50,80,30);
		add(l1);

		l2=new JLabel("Name");
		l2.setBounds(50,100,80,30);
		add(l2);

		t1=new JTextField();
		t1.setBounds(150,50,80,30);
		add(t1);

		t2=new JTextField();
		t2.setBounds(150,100,80,30);
		add(t2);
		
		first=new JButton("FIRST");
		first.setBounds(50,150,80,30);
		add(first);

		next=new JButton("NEXT");
		next.setBounds(150,150,80,30);
		add(next);
		
		last=new JButton("LAST");
		last.setBounds(250,150,80,30);
		add(last);
		
		prev=new JButton("PREV");
		prev.setBounds(350,150,80,30);
		add(prev);
		
		first.addActionListener(this);
		next.addActionListener(this);
		last.addActionListener(this);
		prev.addActionListener(this);
		
		getCon();
		
		setVisible(true);

	}
	
	void getCon()
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/project1?useSSL=false","root","root");
			//"project1" is database name, root is username and password
			Statement stmt=conn.createStatement();
			
			String query="select * from users";
			ResultSet rs=stmt.executeQuery(query);
			
					}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		new today();
	}

	@Override
	public void actionPerformed(ActionEvent ae)
	{
		// TODO Auto-generated method stub
		try
		{
			if(ae.getSource()==first)
			{
				rs.first();
				showrec();
			}	
			else if(ae.getSource()==last)
			{
				rs.last();
				showrec();
			}
			else if(ae.getSource()==prev)
			{
				
			}
			else if(ae.getSource()==next)
			{
				
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	void showrec()
	{	
		try
		{
			t1.setText(rs.getString(1));
			t2.setText(rs.getString(2));
		}
		catch (SQLException e)
		{
			System.out.print(e.getMessage());
			//e.printStackTrace();
		}
	}

}
