/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import DBHandlers.DaoMVC;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.usersBeans;

/**
 *
 * @author user
 */
@WebServlet(name = "updatestudentservlet", urlPatterns = {"/updatestudentservlet"})
public class updatestudentservlet extends HttpServlet 
{

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)   throws ServletException, IOException 
    {
        int studentid = 0;
                HttpSession session=request.getSession();
                String prevfirst=session.getAttribute("name").toString();
                String sfirst=request.getParameter("sfirst");
                String slast=request.getParameter("slast");
		String spass=request.getParameter("spass");
                String sclass=request.getParameter("semail");
		String sgend=request.getParameter("sgend");
                String sdept=request.getParameter("sdept");
		//String tdept=request.getParameter("tdeptname");
		
                System.out.println("RR info:" +sfirst+slast+spass+sclass+sgend+sdept);
                ResultSet rs=DaoMVC.getsid(prevfirst);

		try 
		{
			if(rs.next())
			{
                                studentid=rs.getInt(1);
				System.out.println("sid of "+prevfirst+" is "+studentid);
			}
                }catch (SQLException e) {
			e.printStackTrace();
		}
                
        //2. set the valuse in model class
                
                usersBeans ub =new usersBeans();
                
                ub.setName(sfirst);
                ub.setLast(slast);
                ub.setPass(spass);
                ub.setEmailid(sclass);
                ub.setGend(sgend);
                ub.setDept(sdept);
                //sn.setDept(tdept);
                
                
        //3.pass model class objct to DAO class method
        
               // String str="update newuser set(firstname,lastname,password,email,gender,department)=(?,?,?,?,?,?) where firstname=?";
                
                
                int i=DaoMVC.updateStudentUser(ub,studentid);
                 if(i!=0)
                 {
                    session.setAttribute("name",sfirst);
                    session.setAttribute("last",slast);
                    session.setAttribute("pass",spass);
                    session.setAttribute("emailid",sclass);
                    session.setAttribute("gend",sgend);
                    session.setAttribute("dept",sdept);
  
                    System.out.println("Updated sucessfully");
                    session.setAttribute("msg", "User Profile Updated Sucessfully!");
                    response.sendRedirect("updatestudent.jsp");                  
                 }

    }

   
}
