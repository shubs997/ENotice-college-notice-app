/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import DBHandlers.DaoMVC;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.hod;
import model.usersBeans;


/**
 *
 * @author Shubham
 */
@WebServlet("/generateStudentServlet")

public class generateStudentServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException        
    {
        //1. Retrive all the parameters from jsp
        
                int no=Integer.parseInt(request.getParameter("no"));

        //2. set the valuse in model class
                //usersBeans ub = new usersBeans();
                //ub.setSid(sid);
                //ub.setName(sfname);
                //ub.setPass(spass);
        //3.pass model class objct to DAO class method
        
                //username=MCOE001
                
                
                int scount=DaoMVC.returnStudentCount();
                //int j=DaoMVC.generateStudent(no,scount);

                List unames=getuname(scount,no);
                
                if(unames!=null)
                {
                     System.out.println("\n value inserted in table and list:"+unames.toString());
                     HttpSession session=request.getSession();
                     session.setAttribute("unames",unames);
                     response.sendRedirect("generateuser1.jsp");
                }
                else
                {
                    System.out.println("value not inserted"); //data insertion failed
                    response.sendRedirect("generateuser1.jsp");
                }    
    }

    private List getuname(int scount, int no) 
    {
        ArrayList<String> username = new ArrayList<>();
        int i;
        String uname="MCOE";
        String genuser = null;
        scount++;
        scount+=1000;
        for(i=1;i<=no;i++)
        {
            genuser=uname+scount;
            System.out.println("username for student "+i+" is: "+genuser);
            
            //generate date of joining
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMM d, y");
            String date = simpleDateFormat.format(new Date());
            System.out.println(date);
            
            int j=DaoMVC.generateStudent(genuser,date);
            scount++;
            username.add(genuser);
        }
        return username;
        
    }

}
