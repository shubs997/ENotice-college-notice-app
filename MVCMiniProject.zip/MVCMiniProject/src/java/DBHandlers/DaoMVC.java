package DBHandlers;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.noticeBeans;

import model.usersBeans;


public class DaoMVC
{

    private static Connection connect()
    {
    	String url="jdbc:mysql://localhost:3306/testapp";
    	String username="root";
    	String password="root";

        Connection con=null;
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(url, username, password);
        }

        catch (ClassNotFoundException ex) {
            Logger.getLogger(DaoMVC.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(DaoMVC.class.getName()).log(Level.SEVERE, null, ex);
        }
        return con;
    }


        public static int register(usersBeans ub)
    {
        int i=0;
        String sql="insert into newuser (firstname,lastname,password,email,gender,department) values(?,?,?,?,?,?)";
        Connection con=connect();
        try
        {
            PreparedStatement stm =con.prepareStatement(sql);
            stm.setString(1,ub.getName());
            stm.setString(2,ub.getLast());
            stm.setString(3,ub.getPass());
            stm.setString(4,ub.getEmailid());
            stm.setString(5,ub.getGend());
            stm.setString(6,ub.getDept());

            i = stm.executeUpdate();
        }

        catch (SQLException ex) {
            Logger.getLogger(DaoMVC.class.getName()).log(Level.SEVERE, null, ex);
        }
        return i;
    }






	public static ResultSet loginUser(usersBeans ub, String sql)
	{
		ResultSet rs=null;
		Connection con=connect();
		try
		{
			PreparedStatement stm=con.prepareStatement(sql);
			stm.setString(1, ub.getName());
			stm.setString(2,ub.getPass());

			rs=stm.executeQuery();


		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return rs;
	}




    public static int updateUser(usersBeans ub, String str)
    {
        int i=0;
        ResultSet rs=null;
	Connection con=connect();
	try
	{
                System.out.println("Pass:"+ub.getPass());
                System.out.println("Gender:"+ub.getGend());
                System.out.println("email:"+ub.getEmailid());
                System.out.println("Last:" +ub.getLast());
                System.out.println("Dept:" +ub.getDept());
                System.out.println("name:"+ub.getName());
		PreparedStatement stm=con.prepareStatement(str);

		stm.setString(1, ub.getLast());
                stm.setString(2, ub.getPass());
                stm.setString(3, ub.getEmailid());
                stm.setString(4, ub.getGend());
		stm.setString(5, ub.getDept());

		stm.setString(6,ub.getName()); //for name in where condition



                //stm.setString(7,ub.getName()); //for: "where username=?"
                System.out.println("str:"+str);


                 i=stm.executeUpdate();

                System.out.println("VALUE OF i is" +i);

	} catch (SQLException ex) {
            Logger.getLogger(DaoMVC.class.getName()).log(Level.SEVERE, null, ex);
        }
        return i;
    }

    public static int storeNotice(noticeBeans nb)
    {
        int i=0;
        String sql="insert into notice (title,body,priority,sltUser,files) values(?,?,?,?,?)";
        Connection con=connect();
        try
        {
            PreparedStatement stm =con.prepareStatement(sql);
            stm.setString(1,nb.getTitle());
            stm.setString(2,nb.getBody());
            stm.setString(3,nb.getPriority());
            
            String uarraystr = Arrays.toString(nb.getSltUser());
            stm.setString(4,uarraystr);
            System.out.println("users in DAO class :" +uarraystr);

            stm.setString(5,nb.getFiles());
            
            i = stm.executeUpdate();
        }

        catch (SQLException ex) {
            Logger.getLogger(DaoMVC.class.getName()).log(Level.SEVERE, null, ex);
        }
        return i;
    }

    public static List<noticeBeans> getNoticeList(){



        return null;
    }
    
    public static ArrayList displayNotice(usersBeans ub)
    {
        ResultSet rs=null;
        String sql="select * from notice where sltuser like ?";
	Connection con=connect();
        ArrayList<noticeBeans> nlist = new ArrayList<>();

		try
		{
                    PreparedStatement stm=con.prepareStatement(sql);
                    //stm.setString(1, ub.getName());
                    stm.setString(1,"%"+ub.getName()+"%");
                    System.out.println("value of ? is:"+"%"+ub.getName()+"%");
                    System.out.println("sltuser: " +ub.getName());
                    
                    rs=stm.executeQuery();
                          
                    while(rs.next()){

                        String title = rs.getString(1);
                        String body = rs.getString(2);
                        String priority = rs.getString(3);
                        String sltUser = rs.getString(4);
                        String files = rs.getString(5);
                        System.out.println("Table Contents in dispNotice class:" +title+" "+body+" "+priority+" "+sltUser);
                        
                        //set the values in noticeBeans model
                        noticeBeans nb=new noticeBeans();
                        nb.setTitle(title);
                        nb.setBody(body);
                        nb.setPriority(priority);
                        nb.setStlUserStrings(sltUser);
                        nb.setFiles(files);
                        System.out.println("Table Contents in dispNotice class to model:" +nb.getTitle()+" "+nb.getBody()+" "+nb.getPriority()+" "+nb.getStlUserStrings());
                        
                        nlist.add(nb);
                     }

		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return nlist;
    }

    public static List viewNotice(String NoticeID, usersBeans ub) 
    {   
         ResultSet rs=null;
         String sql="select * from notice where sltuser like ? and title like ?";
	 Connection con=connect();
         ArrayList<noticeBeans> vlist = new ArrayList<>();

		try
		{
                    PreparedStatement stm=con.prepareStatement(sql);
                    //stm.setString(1, ub.getName());
                    stm.setString(1,"%"+ub.getName()+"%");
                    stm.setString(2,NoticeID);
                    System.out.println("value of 1st ? is:"+"%"+ub.getName()+"%");
                    System.out.println("value of 2nd ? is:"+"%"+NoticeID+"%");
                    
                    System.out.println("sltuser: " +ub.getName());
                    
                    rs=stm.executeQuery();
                          
                    while(rs.next()){

                        String title = rs.getString(1);
                        String body = rs.getString(2);
                        String priority = rs.getString(3);
                        String sltUser = rs.getString(4);
                        String files = rs.getString(5);
                        System.out.println("Table Contents in dispNotice class:" +title+" "+body+" "+priority+" "+sltUser);
                        
                        //set the values in noticeBeans model
                        noticeBeans nb=new noticeBeans();
                        nb.setTitle(title);
                        nb.setBody(body);
                        nb.setPriority(priority);
                        nb.setStlUserStrings(sltUser);
                        nb.setFiles(files);
                        System.out.println("Table Contents in dispNotice class to model:" +nb.getTitle()+" "+nb.getBody()+" "+nb.getPriority()+" "+nb.getStlUserStrings());
                        
                        vlist.add(nb);
                     }

		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return vlist;

    }

    





    public ArrayList returnUser()
    {
        ResultSet rs=null;
        ArrayList arr=new ArrayList();
        String returnuser="select firstname from newuser";
        Connection con=connect();
        try
        {
            PreparedStatement pss=con.prepareStatement(returnuser);
            rs=pss.executeQuery();

            while(rs.next()){
                arr.add(rs.getString("firstname"));
            }
        }

        catch (SQLException ex) {
            Logger.getLogger(DaoMVC.class.getName()).log(Level.SEVERE, null, ex);
        }
        return arr;
    }


    }
