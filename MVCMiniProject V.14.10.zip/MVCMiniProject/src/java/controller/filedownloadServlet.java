/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *  
 * @author Shubham
 */
@WebServlet(name = "filedownloadServlet", urlPatterns = {"/filedownloadServlet"})
public class filedownloadServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {  
        PrintWriter out =response.getWriter();
        String fileName = "Test.pdf";
        String filePath = "C:\\Users\\Shubham\\Documents\\NetBeansProjects\\MVCMiniProject\\Files\\";
        response.setContentType("APPLICATION/OCTET-StREAM");
        
        //to display first and download later
        //response.setContentType("APPLICATION/PDF");
        
        
        response.setHeader("Content-Disposition ", "attachment;Filename=\" "+fileName+"\""); //change attachment to inline for type-2
        FileInputStream fi = new FileInputStream(filePath+fileName);
        int i;
        while( (i=fi.read()) !=-1 )
                out.write(i);

        out.close();
        fi.close();
    }

}
